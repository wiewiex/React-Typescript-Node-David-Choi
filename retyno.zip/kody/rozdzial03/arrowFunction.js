var myFunc = function (message) {
    console.log(message);
};
myFunc('Witaj!');
