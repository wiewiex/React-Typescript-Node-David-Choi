// 1
console.log("Zaczynamy...");

// 2
setTimeout(() => {
    console.log("Zaczekałem, ale teraz już kończę.");
}, 3000);

// 3
console.log("Czy to już koniec?");