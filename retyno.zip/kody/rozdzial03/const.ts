namespace constants {
    const val1 = 1;
    val1 = 2;       // błąd zamierzony!
    
    const val2 = [];
    val2.push('Witaj!');
}