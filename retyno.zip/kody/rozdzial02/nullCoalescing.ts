const val1 = undefined;
const val2 = 10;
const result = val1 ?? val2;
console.log(result);