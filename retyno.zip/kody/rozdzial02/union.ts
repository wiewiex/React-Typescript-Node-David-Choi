let unionObj: null | { name: string } = null;
unionObj = { name: 'Janek'};

console.log(unionObj);