let obj: { name: string } & { age: number } = {
    name: 'Tomek',
    age: 25
}

console.log(obj);