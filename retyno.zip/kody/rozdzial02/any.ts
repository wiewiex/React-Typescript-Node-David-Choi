//let val: any = 22;
//val = "to jest łańcuch";
//val = new Array();
//val.push(33);

//console.log(val);

//let val: any = 22;
//val = "to jest łańcuch";
//val = new Array();
//val.nieistniejacametoda(33);

//console.log(val);
