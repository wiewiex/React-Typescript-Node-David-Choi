let literal: "Tomek" | "Linda" | "Jarek" | "Sylwia" = "Linda";
literal = "Sylwia";
//literal = "Janek";
console.log(literal);
