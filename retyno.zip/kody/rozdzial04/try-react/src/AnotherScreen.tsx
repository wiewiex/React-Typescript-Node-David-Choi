import React, { FC } from "react";

const AnotherScreen: FC = () => {
  return <div>Witaj, świecie! Oto druga strona</div>;
};

export default AnotherScreen;