import React from "react";

const ScreenB = () => {
    return <div>Ekran B</div>;
};

export default ScreenB;