import React from "react";

const ScreenA = () => {
    return <div>Ekran A</div>;
};

export default ScreenA;